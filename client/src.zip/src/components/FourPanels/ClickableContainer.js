import React from 'react';
import ClickableArea from './ClickableArea';
import './ClickableContainer.css';

const ClickableContainer = ({ onEffectTrigger }) => {
  return (
    <div className="rectangle-container">
      <ClickableArea onEffectTrigger={onEffectTrigger}>About Me</ClickableArea>
      <ClickableArea onEffectTrigger={onEffectTrigger}>Photos</ClickableArea>
      <ClickableArea onEffectTrigger={onEffectTrigger}>Links</ClickableArea>
      <ClickableArea onEffectTrigger={onEffectTrigger}>Resume</ClickableArea>
    </div>
  );
};

export default ClickableContainer;
