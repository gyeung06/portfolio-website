// App.js
import React, { useState } from 'react';
import './App.css'
import HomePage from './pages/HomePage'; 
import SplashPage from './pages/SplashPage';
import LoadingPage from './pages/LoadingPage';

const App = () => {
  const [loading, setLoading] = useState(false);
  const [splashVisible, setSplashVisible] = useState(true);
  const [homePageVisable, setHomePageVisible] = useState(false);

  const handleSplashExit = () => {
    setTimeout(() => {
      setHomePageVisible(true);
      setSplashVisible(false);
    }, 1000); // Match this with CSS animation duration
  };

  return (
    <div>
      {loading && <LoadingPage />}
      {splashVisible && <SplashPage onEnterComplete={handleSplashExit} />}
      {homePageVisable && <HomePage/>}
    </div>
  );
};

export default App;
