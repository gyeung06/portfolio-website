import React, { useState } from 'react';
import ClickableContainer from '../components/FourPanels/ClickableContainer';
import AboutMe from './AboutMe'; // Import your section components
import Photos from './PhotoGallery';
// ... import other section components ...
import './HomePage.css';

function HomePage() {
  const [currentSection, setCurrentSection] = useState('home');
  const [effectProps, setEffectProps] = useState({ x: 0, y: 0, show: false });

  const handleEffectTrigger = (x, y, newSection) => {
    setEffectProps({ x, y, show: true });
    setTimeout(() => {
      setEffectProps({ ...effectProps, show: false });
      setCurrentSection(newSection);
    }, 3000); // Duration of the animation
  };

  return (
    <div>
      {effectProps.show && <div className="radiate-effect" style={{ left: effectProps.x, top: effectProps.y }}></div>}
      {currentSection === 'home' && <ClickableContainer onEffectTrigger={handleEffectTrigger} />}
      {currentSection === 'aboutMe' && <AboutMe />}
      {currentSection === 'photos' && <Photos />}
      {/* ... other section conditionals ... */}
    </div>
  );
}

export default HomePage;
